<?php

namespace App\Exceptions;

use Themosis\Core\Exceptions\Handler as ExceptionHandler;

class Handler extends ExceptionHandler
{
}
